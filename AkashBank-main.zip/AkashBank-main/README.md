# AkashBank

This is a web application where multiple users can exchange money amongst themselves in a safe and secure manner.

The front end of this application was developed using HTML, CSS and JavaScript and at the backend, a MySQL database is used to store the transaction history as well as the customer details.

the website has been deployed using PythonAnywhere and is currently live. To check it out visit http://akasha.pythonanywhere.com/
